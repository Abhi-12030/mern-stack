import React from 'react'

function Forgotpassword() {
  return (
    <div>F</div>
  )
}

export default Forgotpassword;