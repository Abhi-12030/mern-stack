const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
require('dotenv').config();
const routes = require('./routes/index');
const cookieParser = require('cookie-parser');
const app = express();

  
  
// Middleware
app.use(cors({
    origin: process.env.FRONTEND_URL,
    credentials: true
}));
app.use(express.json({ limit: '50mb' })); // Increase payload size limit
app.use(express.urlencoded({ limit: '50mb', extended: true }));
app.use(cookieParser());

// Routes
app.use("/", routes);

const PORT = process.env.PORT || 8080;

// Connect to the database
connectDB();

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running at http://127.0.0.1:${PORT}`);
});
