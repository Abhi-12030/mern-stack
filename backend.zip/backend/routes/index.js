const express = require('express');
const router = express.Router();
const userSignUpController = require('../controller/user/signUp');
const userSignInController = require('../controller/user/signIn');
const userDetailsController = require('../controller/user/userDetail');
const authToken = require('../middleware/auth');
const userLogout = require('../controller/user/userLogout');
const allUsers = require('../controller/user/allUser');
const updateUser = require('../controller/user/updateUser');
const UploadProductController = require('../controller/Product/UploadProduct');
const getProductController = require('../controller/Product/getProduct');
const getCategoryProduct = require('../controller/Product/getCategoryProduct')
const updateProductController = require('../controller/Product/UpdateProduct')
const getCategoryWiseProduct = require('../controller/product/getCategoryWiseProduct')
const getProductDetails = require('../controller/product/getProductDetails')
const addToCartController = require('../controller/user/addToCartController')
const countAddToCartProduct = require('../controller/user/countAddToCartProduct')
const addToCartViewProduct  = require('../controller/user/addToCartViewProduct')
const updateAddToCartProduct = require('../controller/user/updateAddToCartProduct')
const deleteAddToCartProduct = require('../controller/user/deleteAddToCartProduct')
const searchProduct = require('../controller/Product/searchProduct')
const filterProductController = require('../controller/Product/filterProduct')


// Routes
router.post("/signup", userSignUpController);
router.get("/", (req, res) => {
    res.send("Hello");
});   

router.get("/user-details",authToken,userDetailsController)
router.post("/signin",userSignInController)
router.get("/user-logout",userLogout)
router.get("/all-user",allUsers)
router.post("/update-user",authToken,updateUser) 
router.post("/upload-product",authToken,UploadProductController)
router.get("/get-product",getProductController)

router.get("/get-categoryProduct",getCategoryProduct)
router.post("/upload-product",authToken,UploadProductController)
router.post("/update-product",authToken,updateProductController)

router.post("/category-product",getCategoryWiseProduct)
router.post("/product-details",getProductDetails)
router.get("/search",searchProduct)
router.post("/filter-product",filterProductController)



router.post("/addtocart",authToken,addToCartController)
router.get("/countAddToCartProduct",authToken,countAddToCartProduct)
router.get("/view-card-product",authToken,addToCartViewProduct)
router.post("/update-cart-product",authToken,updateAddToCartProduct)
router.post("/delete-cart-product",authToken,deleteAddToCartProduct)


module.exports = router;
